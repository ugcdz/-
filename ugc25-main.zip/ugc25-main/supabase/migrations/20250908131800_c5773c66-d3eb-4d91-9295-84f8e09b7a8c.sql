-- إنشاء جدول التطبيقات
CREATE TABLE public.apps (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  version TEXT NOT NULL DEFAULT '1.0.0',
  size TEXT NOT NULL,
  rating DECIMAL(2,1) DEFAULT 4.5 CHECK (rating >= 0 AND rating <= 5),
  downloads TEXT DEFAULT '0',
  image_url TEXT,
  download_link TEXT,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- تفعيل RLS للأمان
ALTER TABLE public.apps ENABLE ROW LEVEL SECURITY;

-- السماح للجميع بقراءة التطبيقات النشطة
CREATE POLICY "Anyone can read active apps" 
ON public.apps 
FOR SELECT 
USING (is_active = true);

-- إنشاء Storage bucket للصور
INSERT INTO storage.buckets (id, name, public) VALUES ('app-icons', 'app-icons', true);

-- السماح للجميع برؤية صور التطبيقات
CREATE POLICY "Public app icons read access" 
ON storage.objects 
FOR SELECT 
USING (bucket_id = 'app-icons');

-- إضافة trigger لتحديث updated_at تلقائياً
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_apps_updated_at
  BEFORE UPDATE ON public.apps
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- إدراج البيانات التجريبية
INSERT INTO public.apps (name, description, version, size, rating, downloads, image_url, download_link) VALUES
('تطبيق UGC الأساسي', 'تطبيق شامل لإدارة المحتوى والتواصل مع المجتمع', '1.0.0', '25 MB', 4.8, '10K+', '/lovable-uploads/6e73838e-8809-42d2-9b8d-d4eb6ba03d99.png', '#'),
('UGC Pro', 'النسخة المتقدمة مع ميزات إضافية للمحترفين', '2.1.0', '32 MB', 4.9, '5K+', '/lovable-uploads/6e73838e-8809-42d2-9b8d-d4eb6ba03d99.png', '#');