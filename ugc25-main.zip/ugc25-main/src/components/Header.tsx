import { Button } from "@/components/ui/button";

interface HeaderProps {
  isAppsPage?: boolean;
}

const Header = ({ isAppsPage = false }: HeaderProps) => {
  return (
    <header className="fixed top-0 w-full bg-background/80 backdrop-blur-md border-b z-50">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <img 
            src="/lovable-uploads/6e73838e-8809-42d2-9b8d-d4eb6ba03d99.png" 
            alt="UGC 25 Logo" 
            className="w-10 h-10"
          />
          <h1 className="text-2xl font-bold text-foreground">UGC 25</h1>
        </div>
        
        <nav className="hidden md:flex items-center space-x-8">
          <a href="#home" className="text-foreground hover:text-primary transition-colors">الرئيسية</a>
          <a href="#services" className="text-foreground hover:text-primary transition-colors">خدماتنا</a>
          <a href="#about" className="text-foreground hover:text-primary transition-colors">من نحن</a>
          <a href="#contact" className="text-foreground hover:text-primary transition-colors">تواصل معنا</a>
        </nav>
        
        <Button 
          variant="default" 
          className="bg-gradient-primary hover:shadow-glow"
          onClick={() => window.location.href = isAppsPage ? '/' : '/apps'}
        >
          {isAppsPage ? 'القائمة الرئيسية' : 'تطبيقات UGC'}
        </Button>
      </div>
    </header>
  );
};

export default Header;