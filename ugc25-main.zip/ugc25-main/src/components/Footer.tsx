import { Mail, Phone } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-secondary text-secondary-foreground py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-center">
          {/* Logo & Company */}
          <div className="text-center md:text-right">
            <div className="flex items-center justify-center md:justify-start space-x-3 space-x-reverse mb-4">
              <img 
                src="/lovable-uploads/6e73838e-8809-42d2-9b8d-d4eb6ba03d99.png" 
                alt="UGC 25 Logo" 
                className="w-8 h-8"
              />
              <h3 className="text-2xl font-bold">UGC 25</h3>
            </div>
            <p className="text-sm opacity-80">من أجل مستقبل أفضل</p>
          </div>

          {/* Contact Info */}
          <div className="text-center space-y-2">
            <div className="flex items-center justify-center space-x-2 space-x-reverse">
              <Mail className="w-4 h-4" />
              <span className="text-sm">ugc20021@gmail.com</span>
            </div>
            <div className="flex items-center justify-center space-x-2 space-x-reverse">
              <Phone className="w-4 h-4" />
              <span className="text-sm" dir="ltr">0554597719</span>
            </div>
          </div>

          {/* Copyright */}
          <div className="text-center md:text-left">
            <p className="text-sm opacity-80">
              © 2024 UGC 25. جميع الحقوق محفوظة.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;