import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Smartphone, Globe, Database, Settings, Zap, Shield } from "lucide-react";

const Services = () => {
  const services = [
    {
      icon: Smartphone,
      title: "تطوير تطبيقات الجوال",
      description: "تطبيقات أصلية وهجينة للأندرويد و iOS بأحدث التقنيات",
      features: ["React Native", "Flutter", "Swift", "Kotlin"]
    },
    {
      icon: Globe,
      title: "تطوير المواقع الإلكترونية",
      description: "مواقع ويب متجاوبة وسريعة مع تجربة مستخدم استثنائية",
      features: ["React", "Vue.js", "WordPress", "E-commerce"]
    },
    {
      icon: Database,
      title: "قواعد البيانات والخوادم",
      description: "حلول البنية التحتية وإدارة قواعد البيانات المتقدمة",
      features: ["MySQL", "PostgreSQL", "MongoDB", "Cloud Services"]
    },
    {
      icon: Settings,
      title: "أنظمة إدارة مخصصة",
      description: "أنظمة CRM و ERP مصممة خصيصاً لاحتياجات عملك",
      features: ["CRM", "ERP", "Inventory", "Analytics"]
    },
    {
      icon: Zap,
      title: "تحسين الأداء",
      description: "تحسين سرعة التطبيقات والمواقع لأفضل أداء ممكن",
      features: ["Performance", "SEO", "Speed", "Optimization"]
    },
    {
      icon: Shield,
      title: "الأمان والحماية",
      description: "حلول أمنية متقدمة لحماية بياناتك وخصوصية المستخدمين",
      features: ["SSL", "Encryption", "Authentication", "Security"]
    }
  ];

  return (
    <section id="services" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">خدماتنا</h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            نقدم مجموعة شاملة من الخدمات التقنية المتطورة لتلبية جميع احتياجاتك الرقمية
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <Card 
              key={index} 
              className="group hover:shadow-card hover:-translate-y-2 transition-all duration-300 border-border bg-card"
            >
              <CardHeader className="text-center">
                <div className="w-16 h-16 mx-auto mb-4 bg-gradient-primary rounded-full flex items-center justify-center group-hover:shadow-glow transition-all duration-300">
                  <service.icon className="w-8 h-8 text-white" />
                </div>
                <CardTitle className="text-xl text-card-foreground">{service.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-muted-foreground text-center mb-6 leading-relaxed">
                  {service.description}
                </CardDescription>
                <div className="flex flex-wrap gap-2 justify-center">
                  {service.features.map((feature, idx) => (
                    <span 
                      key={idx}
                      className="px-3 py-1 bg-accent text-accent-foreground rounded-full text-sm font-medium"
                    >
                      {feature}
                    </span>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Services;