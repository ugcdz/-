import { Card, CardContent } from "@/components/ui/card";
import { Target, Eye, Award, Users } from "lucide-react";

const About = () => {
  const stats = [
    { number: "50+", label: "مشروع مكتمل", icon: Award },
    { number: "30+", label: "عميل سعيد", icon: Users },
    { number: "5+", label: "سنوات خبرة", icon: Target },
    { number: "24/7", label: "دعم فني", icon: Eye }
  ];

  return (
    <section id="about" className="py-20 bg-muted/30">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Content */}
          <div>
            <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-8">UGC25</h2>
            <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
              <p>
                نحن فريق من المطورين والمصممين المحترفين في <strong className="text-primary">UGC 25</strong>، 
                نتخصص في تطوير التطبيقات والحلول التقنية المبتكرة التي تهدف إلى تسهيل حياة المستخدمين.
              </p>
              
              <p>
                مع خبرة تمتد لسنوات في مجال تطوير البرمجيات، نحن ملتزمون بتقديم حلول عالية الجودة 
                تلبي احتياجات عملائنا وتتجاوز توقعاتهم.
              </p>
              
              <p>
                رؤيتنا هي <strong className="text-primary">"من أجل مستقبل أفضل"</strong> - 
                نؤمن بقوة التكنولوجيا في تحسين حياة الناس وتطوير المجتمع.
              </p>
            </div>
            
            {/* Mission & Vision */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-12">
              <div className="p-6 bg-card rounded-xl border">
                <Target className="w-10 h-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold text-card-foreground mb-3">رسالتنا</h3>
                <p className="text-muted-foreground">
                  تقديم حلول تقنية مبتكرة تسهل على المستخدمين حياتهم اليومية وتحقق أهدافهم بكفاءة.
                </p>
              </div>
              
              <div className="p-6 bg-card rounded-xl border">
                <Eye className="w-10 h-10 text-primary mb-4" />
                <h3 className="text-xl font-semibold text-card-foreground mb-3">رؤيتنا</h3>
                <p className="text-muted-foreground">
                  أن نكون الشريك التقني الأول في المنطقة لتطوير التطبيقات والحلول الرقمية المتقدمة.
                </p>
              </div>
            </div>
          </div>
          
          {/* Stats */}
          <div className="grid grid-cols-2 gap-6">
            {stats.map((stat, index) => (
              <Card key={index} className="text-center group hover:shadow-card hover:-translate-y-1 transition-all duration-300">
                <CardContent className="p-8">
                  <div className="w-16 h-16 mx-auto mb-4 bg-gradient-primary rounded-full flex items-center justify-center group-hover:shadow-glow transition-all duration-300">
                    <stat.icon className="w-8 h-8 text-white" />
                  </div>
                  <div className="text-3xl font-bold text-primary mb-2">{stat.number}</div>
                  <div className="text-muted-foreground font-medium">{stat.label}</div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;