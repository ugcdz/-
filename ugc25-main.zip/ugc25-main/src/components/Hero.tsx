import { Button } from "@/components/ui/button";
import { ArrowLeft, Smartphone, Code, Users } from "lucide-react";

const Hero = () => {
  return (
    <section id="home" className="min-h-screen bg-gradient-hero flex items-center justify-center relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-10">
        <div className="w-full h-full bg-repeat" style={{
          backgroundImage: `url("data:image/svg+xml,%3Csvg width='40' height='40' viewBox='0 0 40 40' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%23ffffff' fill-opacity='0.03'%3E%3Cpath d='M20 20c0-11.046 8.954-20 20-20v20H20z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E")`
        }}></div>
      </div>
      
      <div className="container mx-auto px-4 text-center relative z-10">
        <div className="max-w-4xl mx-auto">
          {/* Logo */}
          <div className="mb-8 animate-fade-in">
            <img 
              src="/lovable-uploads/6e73838e-8809-42d2-9b8d-d4eb6ba03d99.png" 
              alt="UGC 25 Logo" 
              className="w-32 h-32 mx-auto mb-6 drop-shadow-2xl hover:scale-105 transition-transform duration-300"
            />
          </div>
          
          {/* Main Heading */}
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-6 animate-fade-in">
            UGC 25
          </h1>
          
          {/* Slogan */}
          <p className="text-2xl md:text-3xl text-primary-glow mb-4 animate-fade-in delay-100">
            من أجل مستقبل أفضل
          </p>
          
          {/* Mission */}
          <p className="text-xl text-gray-300 mb-12 max-w-2xl mx-auto leading-relaxed animate-fade-in delay-200">
            نحن متخصصون في تطوير التطبيقات الذكية التي تهدف إلى تسهيل حياة المستخدمين وتحسين تجربتهم اليومية
          </p>
          
          {/* CTA Buttons */}
          <div className="flex justify-center items-center mb-16 animate-fade-in delay-300">
            <Button 
              size="lg" 
              className="bg-gradient-primary hover:shadow-glow text-lg px-8 py-4"
              onClick={() => window.location.href = '/apps'}
            >
              تطبيقات UGC
              <ArrowLeft className="mr-2 h-5 w-5" />
            </Button>
          </div>
          
          {/* Features Icons */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 animate-fade-in delay-400">
            <div className="flex flex-col items-center p-6 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10">
              <Smartphone className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">تطبيقات جوال</h3>
              <p className="text-gray-300 text-center">تطوير تطبيقات متقدمة للهواتف الذكية</p>
            </div>
            
            <div className="flex flex-col items-center p-6 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10">
              <Code className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">حلول تقنية</h3>
              <p className="text-gray-300 text-center">برمجة وتطوير الأنظمة المخصصة</p>
            </div>
            
            <div className="flex flex-col items-center p-6 bg-white/5 backdrop-blur-sm rounded-xl border border-white/10">
              <Users className="w-12 h-12 text-primary mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">دعم مستمر</h3>
              <p className="text-gray-300 text-center">خدمة عملاء متميزة وصيانة دورية</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;