import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/Header";
import Footer from "@/components/Footer";

const Apps = () => {
  const [apps, setApps] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    fetchApps();
  }, []);

  const fetchApps = async () => {
    try {
      const { data, error } = await supabase
        .from('apps')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) throw error;
      
      setApps(data || []);
    } catch (error) {
      console.error('Error fetching apps:', error);
      toast({
        title: "خطأ في تحميل التطبيقات",
        description: "حدث خطأ أثناء تحميل قائمة التطبيقات",
        variant: "destructive"
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Header isAppsPage={true} />
      
      {/* Hero Section */}
      <section className="pt-24 pb-12 bg-gradient-hero relative">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
            تطبيقات UGC
          </h1>
          <p className="text-xl text-gray-300 max-w-2xl mx-auto mb-8">
            حمل تطبيقاتنا المتطورة واستمتع بتجربة فريدة ومميزة
          </p>
        </div>
      </section>

      {/* Apps Grid */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          {isLoading ? (
            <div className="text-center">
              <p className="text-muted-foreground">جاري تحميل التطبيقات...</p>
            </div>
          ) : (
            <div className="text-center">
              <p className="text-muted-foreground mb-4">لا توجد تطبيقات متاحة حالياً</p>
              <p className="text-sm text-muted-foreground">ستتوفر التطبيقات قريباً...</p>
            </div>
          )}

          {/* Instructions */}
          <div className="mt-16 max-w-3xl mx-auto">
            <Card className="bg-accent/50">
              <CardHeader>
                <CardTitle className="text-center text-foreground">كيفية تحميل التطبيقات</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-start space-x-3 space-x-reverse">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                    1
                  </div>
                  <p className="text-muted-foreground">اضغط على زر "تحميل التطبيق" للتطبيق المطلوب</p>
                </div>
                <div className="flex items-start space-x-3 space-x-reverse">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                    2
                  </div>
                  <p className="text-muted-foreground">اسمح بالتحميل من المصادر غير المعروفة في إعدادات هاتفك (للأندرويد)</p>
                </div>
                <div className="flex items-start space-x-3 space-x-reverse">
                  <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                    3
                  </div>
                  <p className="text-muted-foreground">قم بتثبيت التطبيق واستمتع بالمميزات الجديدة</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Contact CTA */}
          <div className="mt-16 text-center">
            <Card className="bg-gradient-primary text-white border-0 max-w-2xl mx-auto">
              <CardContent className="pt-8">
                <h3 className="text-2xl font-bold mb-4">هل تواجه مشكلة في التحميل؟</h3>
                <p className="text-white/80 mb-6">
                  تواصل معنا وسنساعدك في حل أي مشكلة تواجهها
                </p>
                <Button 
                  variant="secondary" 
                  size="lg"
                  onClick={() => window.location.href = '/#contact'}
                >
                  تواصل معنا
                  <ArrowRight className="mr-2 h-4 w-4" />
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Apps;