import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.69ad4b0392e7436ba9d3e72406105049',
  appName: 'ugc25-future-makers',
  webDir: 'dist',
  server: {
    url: 'https://69ad4b03-92e7-436b-a9d3-e72406105049.lovableproject.com?forceHideBadge=true',
    cleartext: true
  },
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      backgroundColor: "#1a1a1a",
      androidSplashResourceName: "splash",
      androidScaleType: "CENTER_CROP",
      showSpinner: false
    }
  }
};

export default config;